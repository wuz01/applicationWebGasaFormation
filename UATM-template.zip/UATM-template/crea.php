<?php
						
						if( !empty($_POST['remail']) && !empty($_POST['rpassword']) && ($_POST['rpassword']==$_POST['rcpassword']))
						{
						
						// Connexion à la base de données
						
						include("db/dbcnx.php"); 
						
							$rq='nex';
							$reponse = $bdd->query('SELECT * FROM etudiants');
							
							while ($donnees = $reponse->fetch())
							{
								if ( $donnees['email']==$_POST['remail'] )
								{
									$rq='ex';
								}
							}
							$reponse->closeCursor();
						
							if ($rq=='nex')
							{
							// Insertion du message à l'aide d'une requête préparée
						
							$bdd->exec('INSERT INTO etudiants (nom, prenoms,  date_nais, nationalite, sexe, adresse, telephone,  ville, noms_pere, noms_mere, email, password) 
							VALUES(\'' . $_POST['rnom'] . '\',\'' . $_POST['rprenom'] . '\',\'' . $_POST['rdatea']. '-' .$_POST['rdatem']. '-' .$_POST['rdatej']. '\',\'' . $_POST['rnationalite'] . '\',\'' . $_POST['rsexe'] . '\',\'' . $_POST['radresse'] . '\',\'' . $_POST['rtelephone'] . '\',\'' . $_POST['rville'] . '\',\'' . $_POST['rnoms_pere'] . '\',\'' . $_POST['rnoms_mere'] . '\',\'' . $_POST['remail']. '\',\'' . $_POST['rpassword'].'\')');


					
							header('Location:index.php?rq=' . $rq);
							}else{
							$rq='ex';
							header('Location:create_account.php?rq=' . $rq);
							}
							

						}else{
						$rq='ex';
							header('Location:create_account.php?rq=' . $rq);
							}
					?>