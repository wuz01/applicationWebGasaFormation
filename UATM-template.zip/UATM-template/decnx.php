<?php
	session_start();
	$_SESSION['email'] ='';
	$_SESSION['motdepasse'] ='';
	session_destroy();
	header('Location: index.php');
?>