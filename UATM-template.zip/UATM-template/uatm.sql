-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  mar. 19 mai 2020 à 12:16
-- Version du serveur :  5.7.24
-- Version de PHP :  7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `uatm`
--

-- --------------------------------------------------------

--
-- Structure de la table `admins`
--

DROP TABLE IF EXISTS `admins`;
CREATE TABLE IF NOT EXISTS `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) NOT NULL,
  `prenoms` varchar(255) NOT NULL,
  `sexe` varchar(200) NOT NULL,
  `tel` int(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `adresse` varchar(255) NOT NULL,
  `pseudo` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `campus` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `admins`
--

INSERT INTO `admins` (`id`, `nom`, `prenoms`, `sexe`, `tel`, `email`, `adresse`, `pseudo`, `password`, `campus`) VALUES
(1, 'admi1', 'admi1', 'Masculin', 5465315, 'admi@li.fr', 'qwsexdrcftvgybhunij,ok;pl', 'admi1', 'admi@li.fr', 'Site de Calavi'),
(2, 'admi2', 'admi2', 'Masculin', 2615606, 'admi2@li.fr', 'uytresdtfyguhi', 'admi2', 'admi2@li.fr', 'Site de Calavi');

-- --------------------------------------------------------

--
-- Structure de la table `etudiants`
--

DROP TABLE IF EXISTS `etudiants`;
CREATE TABLE IF NOT EXISTS `etudiants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) NOT NULL,
  `prenoms` varchar(255) NOT NULL,
  `date_nais` date NOT NULL,
  `nationalite` varchar(255) NOT NULL,
  `sexe` varchar(200) NOT NULL,
  `adresse` varchar(255) NOT NULL,
  `telephone` int(50) NOT NULL,
  `ville` varchar(255) NOT NULL,
  `noms_pere` varchar(255) NOT NULL,
  `noms_mere` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `etudiants`
--

INSERT INTO `etudiants` (`id`, `nom`, `prenoms`, `date_nais`, `nationalite`, `sexe`, `adresse`, `telephone`, `ville`, `noms_pere`, `noms_mere`, `email`, `password`) VALUES
(5, 'leto', 'leto', '1950-10-03', 'Australia', 'Masculin', 'bfqdjkfbqlskn', 86541564, 'fjqbsjkfnsqkj', 'kjbdqkjsnfk', 'vsqhvdjhqbk,', 'leto@live.fr', 'leto@live.fr');

-- --------------------------------------------------------

--
-- Structure de la table `inscriptions`
--

DROP TABLE IF EXISTS `inscriptions`;
CREATE TABLE IF NOT EXISTS `inscriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_etudiant` int(255) NOT NULL,
  `date_ins` date NOT NULL,
  `cycle` varchar(255) NOT NULL,
  `filiere` varchar(255) NOT NULL,
  `formation` varchar(255) NOT NULL,
  `campus` varchar(255) NOT NULL,
  `adresse_par` varchar(255) NOT NULL,
  `email_par` varchar(255) NOT NULL,
  `tel_par` int(200) NOT NULL,
  `ville_par` varchar(255) NOT NULL,
  `prof_p` varchar(255) NOT NULL,
  `adresse_ets_p` varchar(255) NOT NULL,
  `tel_ets_p` int(255) NOT NULL,
  `prof_m` varchar(255) NOT NULL,
  `adresse_ets_m` varchar(255) NOT NULL,
  `tel_ets_m` int(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `inscriptions`
--

INSERT INTO `inscriptions` (`id`, `id_etudiant`, `date_ins`, `cycle`, `filiere`, `formation`, `campus`, `adresse_par`, `email_par`, `tel_par`, `ville_par`, `prof_p`, `adresse_ets_p`, `tel_ets_p`, `prof_m`, `adresse_ets_m`, `tel_ets_m`) VALUES
(1, 5, '2020-05-17', 'Licence Professionnelle 1', 'Electronique', 'Initiale', 'Site de Calavi', 'nhvgcfdxrdfgvhbj', 'leto@live.fr', 5065065, 'jhgvycftrxcfv', 'hgfcxerytyv', 'hgcxecvb', 86486, 'vfcghjknklbvh', 'gjcxrexcv', 6504);

-- --------------------------------------------------------

--
-- Structure de la table `pieces`
--

DROP TABLE IF EXISTS `pieces`;
CREATE TABLE IF NOT EXISTS `pieces` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `id_etudiant` int(255) NOT NULL,
  `id_ins` int(255) NOT NULL,
  `libel` varchar(255) NOT NULL,
  `chemin` varchar(255) NOT NULL,
  `etat` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `pieces`
--

INSERT INTO `pieces` (`id`, `id_etudiant`, `id_ins`, `libel`, `chemin`, `etat`) VALUES
(1, 5, 1, 'Lettre de motivation manuscrite, adressée au Président de L’UATM', 'lettre5w1.png', 'valider'),
(2, 5, 1, 'Fiche d’état civil ou un extrait d’acte de naissance datant de moins d’un an', 'acte5w1.png', 'valider'),
(3, 5, 1, 'Carte nationale d’identité ou du passeport datant de moins d’un an', 'carte5w1.png', 'valider'),
(4, 5, 1, 'Certificat de scolarité de la dernière classe fréquentée', 'certificat5w1.png', 'valider'),
(5, 5, 1, 'Diplôme obtenu ou à défaut, le relevé des notesobtenues au BAC ou équivalent', 'diplome5w1.png', 'valider'),
(6, 5, 1, 'Photo d’identité couleur', 'photo5w1.png', 'valider');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
