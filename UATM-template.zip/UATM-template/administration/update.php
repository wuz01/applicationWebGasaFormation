<?php
session_start();
 if ((empty($_SESSION['login'])) && (empty($_SESSION['password'])))
 {
	header('Location: index.php');
 }else{
	 	include("../db/dbcnx.php"); 
		
		if (isset($_POST['idval']) && isset($_POST['valider']) ){
			
			$bdd->exec('UPDATE pieces SET  etat =\''.$_POST['valider']. '\' WHERE id =\''.$_POST['idval']. '\'');
		}
		
		
		if (isset($_GET['user']) && isset($_GET['ins']) ){
			
		$rep = $bdd->query('SELECT * FROM pieces WHERE id_etudiant=\''.$_GET['user']. '\'  AND id_ins=\''.$_GET['ins']. '\'');
 
		
		$reponse = $bdd->query('SELECT  etudiants.id, inscriptions.id as id_ins, nom, prenoms, filiere, cycle, formation  
							FROM etudiants, inscriptions WHERE etudiants.id=\''.$_GET['user']. '\'  AND inscriptions.id=\''.$_GET['ins']. '\'');
 
		$donnees = $reponse->fetch();
		}else{header('Location: user.php');}
 }

?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <link   href="css/bootstrap.min.css" rel="stylesheet">
    <script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.js"></script>
    <style type="text/css">
     /* Style pour l'exemple*/
      article.col-sm-10, nav.col-sm-2 {
        line-height: 100px;
      }
    </style>
  </head>
  <body>
    
      <header class="row" style="background-color: #ae1517;">
        <div class="col-lg-12">
		<center>
         <a href="index.php" title="Universe" rel="home">
                            <img src="logo.png" alt="Universe">
                        </a>
		</center>
        </div>
      </header>
	  <br>
      <div >
        <nav class="col-sm-3" style="width:20%;">
		<br><br><br>
               <ul class="list-group">
			   
			   <a href="index.php" class="list-group-item">
					
					  Accueil
				  </a>

				  <a href="#" class="list-group-item active">
					
					  Nouvelles Inscriptions
				  </a>
				  <a href="valide.php" class="list-group-item">
					

					  Inscriptions Validées
				  </a>
				  <a href="invalide.php" class="list-group-item">
					
					  Inscriptions Non Validées
				  </a>
				  <a href="decnx.php" class="list-group-item">
					
					  Déconnexion
				  </a>

				</ul>
        </nav>
		</div>
		
        <div >
            <center><h3> <?php echo $donnees['nom']; ?> &nbsp;<?php echo $donnees['prenoms']; ?></h3></center>
            
            
              
                <table class="table table-striped table-bordered" style="width:70%;">
                      <thead>
                        <tr>
                         <th>Filière</th>
                          <th>Cycle</th>
						   <th>Formation</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                     
                               <tr>
                               <td><?php echo $donnees['filiere']; ?></td>
                               <td><?php echo $donnees['cycle']; ?></td>
								<td><?php echo $donnees['formation']; ?></td>
                                <td><a href="#" class="glyphicon glyphicon-trash pull-right" style="color:blue; margin-right:15px;"></a>
								<a href="#" class="glyphicon glyphicon-pencil pull-right" style="color:blue; margin-right:15px;"></a>
								<a href="#" class="glyphicon glyphicon-eye-open pull-right" style="color:blue;margin-right:20px;"></a></td>
                                </tr>
						
                      </tbody>
					  
                </table><br>
				
				<h3 id="valider"> VALIDATION DES PIECES</h3>
				     <table class="table table-striped table-bordered" style="width:70%;">

                      <tbody>
                     <?php
					  if (!empty($rep)){
                      while ($donneex = $rep->fetch())
						{ ?>
                               <tr>
                               <td><h4><i><?php echo $donneex['libel']; ?></h4></i></td>
							   <td><a href="../pieces/<?php echo $donneex['chemin']; ?>" target="_BLANK" class="glyphicon glyphicon-eye-open pull-right" style="color:blue;margin-right:20px;"></a></td>
                               <td><?php echo $donneex['etat']; ?></td>
							   <td>
							   <form action="update.php?user=<?php echo $donnees['id']; ?>&ins=<?php echo $donnees['id_ins']; ?>#valider" method="post">
							   <input type="hidden" value="<?php echo $donneex['id']; ?>" name="idval">
							   <select id="inputSexe" class="form-control" name="valider">
								<option value="Nouveau">Sélectionner</option>
								  <option>valider</option>
								  <option>invalider</option>
								</select>
								<button class="btn btn-lg btn-primary btn-block" type="submit">enregister</button>
								</form>
								</td>
								</tr>
						<?php }} ?>
                      </tbody>
                </table>

        </div>
		
		
     
      
    
  </body>
</html>
