<?php
session_start();
 if ((!empty($_SESSION['login'])) && (!empty($_SESSION['password'])))
 {
	header('Location: user.php');
 }

?>

 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <link   href="css/bootstrap.min.css" rel="stylesheet">
    <script src="js/bootstrap.min.js"></script>
    <style type="text/css">
     /* Style pour l'exemple*/
      article.col-sm-10, nav.col-sm-2 {
        line-height: 100px;
      }
    </style>
  </head>
  <body>
    
      <header class="row" style="background-color: #ae1517;">
        <div class="col-lg-12">
		<center>
         <a href="index.php" title="Universe" rel="home">
                            <img src="logo.png" alt="Universe">
                        </a>
		</center>
        </div>
      </header>
	  <br>
       
        
 <div class="container">
<center>
      <form style="width:30%" action="cnx.php" method="post" class="form-signin">
        <h2 class="form-signin-heading">Connectez-vous</h2>
        <label for="inputPseudo" class="sr-only">Email address</label>
        <input type="text" id="inputPseudo" class="form-control" placeholder="Pseudo" name="pseudo" required autofocus>
		<br>
        <label for="inputPassword" class="sr-only">Password</label>
        <input type="password" id="inputPassword" class="form-control" placeholder="Password" name="password" required>
		<br>
        <button class="btn btn-lg btn-primary btn-block" type="submit">Connexion</button>
		<br>
		<a href="create_account.php">Créer un compte administrateur !</a>
      </form>
</center>
    </div> <!-- /container -->
      
      

    
  </body>
</html>
