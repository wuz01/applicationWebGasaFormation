<?php
						
						if( !empty($_POST['pseudo']) && !empty($_POST['password']) && ($_POST['password']==$_POST['cpassword']))
						{
						
						// Connexion à la base de données
						
						include("../db/dbcnx.php"); 
						
							$rq='nex';
							$reponse = $bdd->query('SELECT * FROM admins');
							
							while ($donnees = $reponse->fetch())
							{
								if ( $donnees['pseudo']==$_POST['pseudo'] )    /////modif apporté
								{
									$rq='ex';
								}
							}
							$reponse->closeCursor();
						
							if ($rq=='nex')
							{
							// Insertion du message à l'aide d'une requête préparée
						
							$bdd->exec('INSERT INTO admins (nom, prenoms, sexe, tel, email, adresse, pseudo,  password,  campus) 
							VALUES(\'' . $_POST['nom'] . '\',\'' . $_POST['prenoms'] . '\',\'' . $_POST['sexe'] . '\',\'' . $_POST['telephone'] . '\',\'' . $_POST['email'] . '\',\'' . $_POST['adresse'] . '\',\'' . $_POST['pseudo'] . '\',\'' . $_POST['password'] . '\',\'' . $_POST['campus'] . '\')');
					
							header('Location:index.php?rq=' . $rq);
							}else{
							$rq='ex';
							header('Location:create_account.php?rq=' . $rq);
							}
							

						}
					?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <link   href="css/bootstrap.min.css" rel="stylesheet">
    <script src="js/bootstrap.min.js"></script>
    <style type="text/css">
     /* Style pour l'exemple*/
      article.col-sm-10, nav.col-sm-2 {
        line-height: 100px;
      }
    </style>
  </head>
  <body>
    
      <header class="row" style="background-color: #ae1517;">
        <div class="col-lg-12">
		<center>
         <a href="index.php" title="Universe" rel="home">
                            <img src="logo.png" alt="Universe">
                        </a>
		</center>
        </div>
      </header>
	  <br>
       
        
 <div class="container">
<center>
      <form style="width:50%" action="create_account.php" method="post" class="form-signin">
        <h2 class="form-signin-heading">Creer un compte Administrateur</h2>
		<br>
        <label for="inputNom" class="sr-only">Nom</label>
        <input type="text" id="inputNom" class="form-control" placeholder="Nom" name="nom" required >
		<br>
		<label for="inputPrenoms" class="sr-only">Prenoms</label>
        <input type="text" id="inputPrenoms" class="form-control" placeholder="Prenoms" name="prenoms" required >
		<br>
		<label for="inputSexe" class="sr-only"  >Sexe</label>
        <select id="inputSexe" class="form-control" name="sexe">
		<option value="">Sexe</option>
		  <option>Masculin</option>
		  <option>Féminin</option>
		</select>
		<br>

		<label for="inputTelephone" class="sr-only">Telephone</label>
        <input type="text" id="inputTelephone" class="form-control" placeholder="Telephone" name="telephone" required >
		<br>
		<label for="inputEmail" class="sr-only">Email Adresse</label>
        <input type="text" id="inputEmail" class="form-control" placeholder="Email Adresse" name="email" required >
		<br>
		<label for="inputAdresse" class="sr-only">Adresse</label>
        <input type="text" id="inputAdresse" class="form-control" placeholder="Adresse" name="adresse" required >
		<br>
		<label for="inputCampus" class="sr-only">Direction Campus</label>
        <select  id="inputCampus" class="form-control"  name="campus">
		<option value="">Direction Campus</option>
		<option>Site de gbégamey</option>
		<option>Site de Agla</option>
		<option>Site de Calavi</option>
		<option>Site de Akpakpa 1</option>
		<option>Site de Akpakpa 2</option>
		<option>Site de Porto-Novo</option>
		<option>Site de Pahou</option>
		</select>
		<br>
		<br>
		<label for="inputPseudo" class="sr-only">Pseudo</label>
        <input type="text" id="inputPseudo" class="form-control" placeholder="Pseudo" name="pseudo" required autofocus>
		<br>
        <label for="inputPassword" class="sr-only">Password</label>
        <input type="password" id="inputPassword" class="form-control" placeholder="Mot de Passe" name="password" required>
		<br>
		<label for="inputCpassword" class="sr-only">Password</label>
        <input type="password" id="inputCpassword" class="form-control" placeholder="Confirmer le Mot de Passe" name="cpassword" required>
		<br>
        <button class="btn btn-lg btn-primary btn-block" type="submit">Creer Compte</button>
		<br><br><br>
		
      </form>
</center>
    </div> <!-- /container -->
      
      

    
  </body>
</html>
