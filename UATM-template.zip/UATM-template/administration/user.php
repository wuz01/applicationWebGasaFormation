<?php
session_start();
 if ((empty($_SESSION['login'])) && (empty($_SESSION['password'])))
 {
	header('Location: index.php');
 }else{
	 	include("../db/dbcnx.php"); 
	
		if (isset($_GET['del'])){
			
			$bdd->exec('DELETE FROM  inscriptions  WHERE id =\''.$_GET['del']. '\'');
			header('Location: user.php');  
		}
	
		$reponse = $bdd->query('SELECT  etudiants.id, inscriptions.id as id_ins, nom, prenoms, filiere, cycle, formation  
              FROM etudiants, inscriptions WHERE etudiants.id=inscriptions.id_etudiant AND campus=\''.$_SESSION['campus']. '\'');

 }

?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <link   href="css/bootstrap.min.css" rel="stylesheet">
    <script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.js"></script>
    <style type="text/css">
     /* Style pour l'exemple*/
      article.col-sm-10, nav.col-sm-2 {
        line-height: 100px;
      }
    </style>
  </head>
  <body>
    
      <header class="row" style="background-color: #ae1517;">
        <div class="col-lg-12">
		<center>
         <a href="index.php" title="Universe" rel="home">
                            <img src="logo.png" alt="Universe">
                        </a>
		</center>
        </div>
      </header>
	  <br>
      <div >
        <nav class="col-sm-3" style="width:20%;">
               <ul class="list-group">
				  <a href="#" class="list-group-item active">
					
					  Nouvelles Inscriptions
				  </a>
				  <a href="valide.php" class="list-group-item">
					

					  Inscriptions Validées
				  </a>
				  <a href="invalide.php" class="list-group-item">
					
					  Inscriptions Non Validées
				  </a>
				  <a href="decnx.php" class="list-group-item">
					
					  Déconnexion
				  </a>
				</ul>
        </nav>
		</div>
		
        <div >
            <h3>LISTE DE NOUVELLES INSCRIPTIONS</h3>
            
            
              
                <table class="table table-striped table-bordered" style="width:78%;">
                      <thead>
                        <tr>
                          <th>Noms</th>
                          <th>Prénoms</th>
                          <th>Filière</th>
                          <th>Cycle</th>
						   <th>Formation</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php
					  if (!empty($reponse)){
                      while ($donnees = $reponse->fetch())
						{ ?>
                               <tr>
                               <td><?php echo $donnees['nom']; ?></td>
                                <td><?php echo $donnees['prenoms']; ?></td>
                               <td><?php echo $donnees['filiere']; ?></td>
                               <td><?php echo $donnees['cycle']; ?></td>
								<td><?php echo $donnees['formation']; ?></td>
                                <td><a href="user.php?del=<?php echo $donnees['id_ins']; ?>" class="glyphicon glyphicon-trash pull-right" style="color:blue; margin-right:15px;"></a>
								<a href="update.php?user=<?php echo $donnees['id']; ?>&ins=<?php echo $donnees['id_ins']; ?>" class="glyphicon glyphicon-pencil pull-right" style="color:blue; margin-right:15px;"></a>
								<a href="update.php?user=<?php echo $donnees['id']; ?>&ins=<?php echo $donnees['id_ins']; ?>" class="glyphicon glyphicon-eye-open pull-right" style="color:blue;margin-right:20px;"></a></td>
                                </tr>
						<?php }} ?>
                      </tbody>
                </table>
       
        </div>
     
      
    
  </body>
</html>
