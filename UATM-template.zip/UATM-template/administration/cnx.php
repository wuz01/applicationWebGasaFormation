<?php

	 include("../db/dbcnx.php"); 

	$reponse = $bdd->query('SELECT * FROM admins');
	$rpx='n';
	while ($donnees = $reponse->fetch())
	{
		if ( ($donnees['pseudo']==$_POST['pseudo']) && ($donnees['password']==$_POST['password']))
		{
			$rpx='y';
			$id=$donnees['id'];
			$campus=$donnees['campus'];
			
		}
	}
	if ($rpx=='y')
	{
			// On démarre la session AVANT d'écrire du code HTML
			session_start();
			$_SESSION['login'] = $_POST['pseudo'];
			$_SESSION['password'] = $_POST['password'];
			$_SESSION['id'] = $id;
			$_SESSION['campus'] = $campus;
			
			
			// Redirection du visiteur vers la page d'accueil
			header('Location: user.php');
	}
	else
	{
		header('Location: index.php?rq=' . $rpx);
	}
	

?>