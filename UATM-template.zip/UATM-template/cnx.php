<?php

	 include("db/dbcnx.php"); 

	$reponse = $bdd->query('SELECT * FROM etudiants');
	$rpx='n';
	while ($donnees = $reponse->fetch())
	{
		if ( ($donnees['email']==$_POST['email']) && ($donnees['password']==$_POST['password']))
		{
			$rpx='y';
			$id=$donnees['id'];
			
		}
	}
	if ($rpx=='y')
	{
			// On démarre la session AVANT d'écrire du code HTML
			session_start();
			$_SESSION['email'] = $_POST['email'];
			$_SESSION['password'] = $_POST['password'];
			$_SESSION['id'] = $id;
			
			
			$reponse = $bdd->query('SELECT * FROM inscriptions WHERE id_etudiant=\'' . $_SESSION['id'] .'\' ORDER BY date_ins DESC LIMIT 1');
			
			if (!empty($reponse)){
				$donnees = $reponse->fetch();
				$_SESSION['id_ins'] = $donnees['id'];
			}
			// Redirection du visiteur vers la page d'accueil
			header('Location: account.php');
	}
	else
	{
		header('Location: index.php?rq=' . $rpx);
	}
	

?>