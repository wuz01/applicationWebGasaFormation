<?php		session_start();
					 if ((empty($_SESSION['email'])) && (empty($_SESSION['password'])))
					 {
						header('Location: index.php');
					 }
					 else
					{
						
						if (isset($_SESSION['id_ins'])  && $_SESSION['id_ins']!==''){
							header('Location: account.php');
							exit;
						}
						
						if( !empty($_POST['rcycle']) && !empty($_POST['rfiliere']) && !empty($_POST['rformation']) && !empty($_POST['rcampus']))
						{
						
						// Connexion à la base de données
						
						include("db/dbcnx.php"); 

							// Insertion du message à l'aide d'une requête préparée
						
							$bdd->exec('INSERT INTO inscriptions (id_etudiant, date_ins, cycle, filiere, formation, campus,  adresse_par,
									email_par, tel_par, ville_par, prof_p, adresse_ets_p, tel_ets_p , prof_m , adresse_ets_m , tel_ets_m) 
							VALUES(\'' . $_SESSION['id'] . '\', NOW() ,\'' 
							. $_POST['rcycle']. '\',\'' .$_POST['rfiliere']
							. '\',\'' .$_POST['rformation']. '\',\'' . $_POST['rcampus']. '\',\'' .$_POST['radresse_par']
							. '\',\'' . $_POST['remail_par'] . '\',\'' . $_POST['rtel_par'] 
							. '\',\'' . $_POST['rville_par'] . '\',\'' . $_POST['rprof_p']
							. '\',\'' . $_POST['radresse_ets_p'] . '\',\'' . $_POST['rtel_ets_p']
							. '\',\'' . $_POST['rprof_m']. '\',\'' . $_POST['radresse_ets_m']
							. '\',\'' . $_POST['rtel_ets_m'].'\')');
					
							$lastId = $bdd->lastInsertId();
							
							$_SESSION['id_ins'] = $lastId;
							
							header('Location:pieces.php');
						}
					}
					?>


<!DOCTYPE html>
<!--[if lt IE 7]> <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="en"> 
<![endif]-->
<!--[if IE 7]> <html class="no-js lt-ie9 lt-ie8" lang="en"> 
<![endif]-->
<!--[if IE 8]> <html class="no-js lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en"> <!--<![endif]-->

<!-- Mirrored from demo.esmeth.com/universe/Blue/courses.php by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 12 Feb 2015 19:12:26 GMT -->

<!-- Mirrored from www.jetsitem.net/template/template075/courses.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 22 May 2016 14:25:39 GMT -->
<head>
    <title>Universe - College Education Responsive Template</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Description for my template">
    <meta name="author" content="Esmet">
    <meta charset="UTF-8">

    <link href='http://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800' rel='stylesheet' type='text/css'>
        
    <!-- CSS Bootstrap & Custom -->
    <link href="bootstrap/css/bootstrap.css" rel="stylesheet" media="screen">
    <link href="css/font-awesome.min.css" rel="stylesheet" media="screen">
    <link href="css/animate.css" rel="stylesheet" media="screen">
    
    <link href="style.css" rel="stylesheet" media="screen">
        
    <!-- Favicons -->
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    
    <!-- JavaScripts -->
    <script src="js/jquery-1.10.2.min.js"></script>
    <script src="js/jquery-migrate-1.2.1.min.js"></script>
    <script src="js/modernizr.js"></script>
    <!--[if lt IE 8]>
    <div style=' clear: both; text-align:center; position: relative;'>
            <a href="http://www.microsoft.com/windows/internet-explorer/default.aspx?ocid=ie6_countdown_bannercode"><img src="http://storage.ie6countdown.com/assets/100/images/banners/warning_bar_0000_us.jpg" border="0" alt="" /></a>
        </div>
    <![endif]-->
</head>
<body>

    <!-- This one in here is responsive menu for tablet and mobiles -->
    <div class="responsive-navigation visible-sm visible-xs">
        <a href="#" class="menu-toggle-btn">
            <i class="fa fa-bars"></i>
        </a>
        <div class="responsive_menu">
            <ul class="main_menu">
                <li><a href="index.php">Home</a></li>
                <li><a href="#">Events</a>
                    <ul>
                        <li><a href="events-grid.php">Events Grid</a></li>
                        <li><a href="events-list.php">Events List</a></li>
                        <li><a href="event-single.php">Event Details</a></li>
                    </ul>
                </li>
                <li><a href="#">Courses</a>
                    <ul>
                        <li><a href="courses.php">Course List</a></li>
                        <li><a href="course-single.php">Course Single</a></li>
                    </ul>
                </li>
                <li><a href="#">Blog Entries</a>
                    <ul>
                        <li><a href="blog.php">Blog Grid</a></li>
                        <li><a href="blog-single.php">Blog Single</a></li>
                        <li><a href="blog-disqus.php">Blog Disqus</a></li>
                    </ul>
                </li>
                <li><a href="#">Pages</a>
                    <ul>
                        <li><a href="archives.php">Archives</a></li>
                        <li><a href="shortcodes.php">Shortcodes</a></li>
                        <li><a href="gallery.php">Our Gallery</a></li>
                    </ul>
                </li>
                <li><a href="contact.php">Contact</a></li>
            </ul> <!-- /.main_menu -->
            <ul class="social_icons">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                <li><a href="#"><i class="fa fa-rss"></i></a></li>
            </ul> <!-- /.social_icons -->
        </div> <!-- /.responsive_menu -->
    </div> <!-- /responsive_navigation -->


    <header class="site-header">
        <div class="container">
            <div class="row">
                <div class="col-md-4 header-left">
                    <p><i class="fa fa-phone"></i> (229)95 95 32 07</p>
                    <p><i class="fa fa-envelope"></i> <a href="mailto:email@universe.com">ufrge@uatm-gasa.com</a></p>
                </div> <!-- /.header-left -->

                <div class="col-md-4">
                    <div class="logo">
                        <a href="index.php" title="Universe" rel="home">
                            <img src="images/logo.png" alt="Universe">
                        </a>
                    </div> <!-- /.logo -->
                </div> <!-- /.col-md-4 -->

                <div class="col-md-4 header-right">
                    <ul class="small-links">
                        <li><a href="#">About Us</a></li>
                        <li><a href="#">Contact</a></li>
                        <li><a href="#">Apply Now</a></li>
                    </ul>

                </div> <!-- /.header-right -->
            </div>
        </div> <!-- /.container -->

            <div class="nav-bar-main" role="navigation">
            <div class="container">
                <nav class="main-navigation clearfix visible-md visible-lg" role="navigation">
                        <ul class="main-menu sf-menu">
                            <li ><a href="index.php">Accueil</a></li>
                            <li><a href="#">Formations</a>
                                <ul class="sub-menu">
                                    <li><a href="blog.php">Nos Formations</a></li>
                                    <li><a href="blog-single.php">BTS</a></li>
                                    <li><a href="blog-disqus.php">Licence/Bachelor</a></li>
									<li><a href="blog-disqus.php">Master</a></li>
									<li><a href="blog-disqus.php">Doctorat</a></li>
									<li><a href="blog-disqus.php">Ecole Normale Superieure</a></li>
									<li><a href="blog-disqus.php">Comprendre le LMD</a></li>
                                </ul>
                            </li>
                            <li><a href="#">Inscription en ligne</a>
                                <ul class="sub-menu">
                                    <li><a href="courses.php">Formation Francophone </a></li>
                                    <li><a href="course-single.php">Formation Bilingues</a></li>
                                </ul>
                            </li>

                            <li><a href="#">Evènements</a>
                                <ul class="sub-menu">
                                    <li><a href="events-grid.php">Events Grid</a></li>
                                    <li><a href="events-list.php">Events List</a></li>
                                    <li><a href="event-single.php">Events Details</a></li>
                                </ul>
                            </li>
                            <li><a href="#">Pages</a>
                                <ul class="sub-menu">
                                    <li><a href="archives.php">Archives</a></li>
                                    <li><a href="shortcodes.php">Shortcodes</a></li>
                                    <li><a href="gallery.php">Our Gallery</a></li>
                                </ul>
                            </li>
                            <li><a href="contact.php">Contact</a></li>
                        </ul> <!-- /.main-menu -->

                        <ul class="social-icons pull-right">
                            <li><a href="#" data-toggle="tooltip" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#" data-toggle="tooltip" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#" data-toggle="tooltip" title="Pinterest"><i class="fa fa-pinterest"></i></a></li>
                            <li><a href="#" data-toggle="tooltip" title="Google+"><i class="fa fa-google-plus"></i></a></li>
                            <li><a href="#" data-toggle="tooltip" title="RSS"><i class="fa fa-rss"></i></a></li>
                        </ul> <!-- /.social-icons -->
                </nav> <!-- /.main-navigation -->
            </div> <!-- /.container -->
        </div> <!-- /.nav-bar-main -->

    </header> <!-- /.site-header -->
    
    
    
    <!-- Being Page Title -->
    <div class="container">
        <div class="page-title clearfix">
            <div class="row">
                <div class="col-md-12">
                    <h6><a href="index.php">Home</a></h6>
                    <h6><span class="page-active">Inscription En Ligne</span></h6>
                </div>
            </div>
        </div>
    </div>


    <div class="container">
        <div class="row">

            <!-- Here begin Main Content -->
            <div class="col-md-8">

                <div class="row">
                    <div class="col-md-12">
                        <div class="widget-main">
                            <div class="widget-inner">
                                <div class="course-search">
                                    <h3>Inscription Scolaire</h3>
			<script>function checkrequired(which){
												var pass=true
												if (document.images){
												for (i=0;i<which.length;i++){
												var tempobj=which.elements[i]
												if (tempobj.name.substring(0,1)=="r"){
												if (((tempobj.type=="text"||tempobj.type=="textarea")&&tempobj.value=='')||(tempobj.type.toString().charAt(0)=="s"&&tempobj.selectedIndex==-1)){
												pass=false
												break
												}
												}
												}
												}
												if (!pass){
												alert("Tous les champs marqués (*) sont obligatoires, merci de bien vouloir les renseigner")
												return false
												}
												else
												return true
												}
			</script>

<form name="formcheck"  onsubmit="return checkrequired(this)" action="inscription.php" method="post" id="quick_form" class="course-search-form">

 <table class="table" style="width:500px;">

 <tr>
<td>Nos Cycles : <font color="red">*</font></td>
<td><select name="rcycle">
<option value="">-----------------------------------------</option>
<option>BTS</option>
<option>Licence Professionnelle 1</option>
<option>Licence Professionnelle 1</option>
<option>Licence Professionnelle 1</option>
<option>Doctorat</option>
</select>
</td>
</tr>

<tr>
<td>Nos Filières : <font color="red">*</font></td>
<td><select name="rfiliere">
<option value="">-----------------------------------------</option>
<option>Informatique de Gestion</option>
<option>Télécommunication</option>
<option>Informatique Industrielle et Maintenance (2IM)</option>
<option>Electronique</option>
<option>Génie Electrique et Informatique</option>
<option>Chimie Alimentaire et Contrôle de Qualité <br><br></option>
<option value="">-----------------------------------------</option>
<option>Banque et Finance</option>
<option>Finance Comptabilité et Gestion</option>
<option>Communication d'Entreprise</option>
<option>Management des Ressources Humaines</option>
<option>Transport et Logistique</option>
<option>Marketing et Action Commerciale</option>
<option>Assurance</option>
<option>Economie et Gestion</option>
<option>Secrétariat Bureautique / Bilingue</option>
<option>Journalisme</option>
<option>Tourisme et Loisirs</option>
<option>Assistant Gestion PME / PMI (AG-PME/PMI)</option>
<option value="">-----------------------------------------</option>
<option>Sciences Agronomiques</option>
<option>Sciences Juridiques et Politiques</option>
<option>Biotechnologie</option>
</select>
</td>
</tr>

 <tr>
<td>Nos Formations : <font color="red">*</font></td>
<td><select name="rformation">
<option>Initiale</option>
<option>Continue</option>
<option>E-learn</option>
</select>
</td>
</tr>

 <tr>
<td>Nos Campus : <font color="red">*</font></td>
<td><select name="rcampus">
<option value="">-----------------------------------------</option>
<option>Site de gbégamey</option>
<option>Site de Agla</option>
<option>Site de Calavi</option>
<option>Site de Akpakpa 1</option>
<option>Site de Akpakpa 2</option>
<option>Site de Porto-Novo</option>
<option>Site de Pahou</option>
</select>
</td>
</tr>

<tr>
<td></td><td></td>
</tr>
</table>


<table class="table" style="width:500px;">

<h3>Situation Familiale</h3><br>

<tr>
<td>Adresse des parents : <font color="red">*</font></td><td><input type="text" name="radresse_par" size="50"></td>
</tr>
<tr>
<td>E-mail : <font color="red">*</font></td><td><input style="border: 1px solid #ddd; height:30px; width:284px;" type="email" name="remail_par" size="50"></td>
</tr>
<tr>
<td>Téléphone : <font color="red">*</font></td><td><input type="text" name="rtel_par" size="30"></td>
</tr>
<tr>
<td>Ville : <font color="red">*</font></td><td><input type="text" name="rville_par" size="30"></td>
</tr>
<tr>
<td></td><td></td>
</tr>
</table>

<table class="table" style="width:500px;">

<h3>Profession de vos parents</h3><br>


<tr>
<td>Profession de votre Père : <font color="red">*</font></td><td><input type="text" name="rprof_p" size="50"></td>
</tr>

<tr>
<td>Adresse Entreprise : <font color="red">*</font></td><td><input type="text" name="radresse_ets_p" size="50"></td>
</tr>

<tr>
<td>Téléphone : <font color="red">*</font></td><td><input type="text" name="rtel_ets_p" size="30"></td>
</tr>

</table>

<table class="table" style="width:500px;">

<tr>
<td>Profession de votre Mère : <font color="red">*</font></td><td><input type="text" name="rprof_m" size="50"></td>
</tr>

<tr>
<td>Adresse Entreprise : <font color="red">*</font></td><td><input type="text" name="radresse_ets_m" size="50"></td>
</tr>

<tr>
<td>Téléphone : <font color="red">*</font></td><td><input type="text" name="rtel_ets_m" size="30"></td>
</tr>

<tr>
<td></td><td>
<br><br>
<input class="btn btn-primary" style="color:#fff; background-color:#ae1517" type="submit" name="" value="Valider">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input class="btn btn-primary" style="color:#fff; background-color:#ae1517" type="reset" name="" value="Réinitialiser">
</td>
</tr>
</table>

</form>

                                </div>
                            </div> <!-- /.widget-inner -->
                        </div> <!-- /.widget-main -->
                    </div> <!-- /.col-md-12 -->
                </div> <!-- /.row -->


            </div> <!-- /.col-md-8 -->


            <!-- Here begin Sidebar -->
            <div class="col-md-4">

                              <div class="widget-main">
                    <div class="widget-main-title">
                        <h4 class="widget-title">Nos Campus</h4>
                    </div>
                    <div class="widget-inner">
                        <div class="prof-list-item clearfix">
                           <div class="prof-thumb">
                                <img src="images/prof/prof1.jpg" alt="Profesor Name">
                            </div> <!-- /.prof-thumb -->
                            <div class="prof-details">
                                <h5 class="prof-name-list">Site de Gbégamey</h5>
                                <p class="small-text">2ème rue à gauche apres le CEG Gbégamey <br> Tel (229 )21 30 86 87</p>
                            </div> <!-- /.prof-details -->
                        </div> <!-- /.prof-list-item -->
                        <div class="prof-list-item clearfix">
                           <div class="prof-thumb">
                                <img src="images/prof/prof2.jpg" alt="Profesor Name">
                            </div> <!-- /.prof-thumb -->
                            <div class="prof-details">
                                <h5 class="prof-name-list">Site de Akpakpa 2</h5>
                                <p class="small-text">A la descente du nouveau pont et PK6 route de Porto Novo carrefour Abattoir <br> Tel (229) 95 42 98 11</p>
                            </div> <!-- /.prof-details -->
                        </div> <!-- /.prof-list-item -->
                        <div class="prof-list-item clearfix">
                           <div class="prof-thumb">
                                <img src="images/prof/prof3.jpg" alt="Profesor Name">
                            </div> <!-- /.prof-thumb -->
                            <div class="prof-details">
                                <h5 class="prof-name-list">Site de Calavi</h5>
                                <p class="small-text">2ème Etage, Bâtiment Continental bank, Face à la Mairie <br> Tel (229) 95 42 98 11</p>
                            </div> <!-- /.prof-details -->
							<br>
							<a href="#"> Affichez Plus</a>
                        </div> <!-- /.prof-list-item -->
                    </div> <!-- /.widget-inner -->
                </div> <!-- /.widget-main -->

                <div class="widget-main">
                    <div class="widget-main-title">
                        <h4 class="widget-title">Notre Gallerie</h4>
                    </div>
                    <div class="widget-inner">
                        <div class="gallery-small-thumbs clearfix">
                            <div class="thumb-small-gallery">
                                <a class="fancybox" rel="gallery1" href="images/gallery/gallery1.jpg" title="Gallery Tittle One">
                                    <img src="images/gallery/gallery-small-thumb1.jpg" alt="" />
                                </a>
                            </div>
                            <div class="thumb-small-gallery">
                                <a class="fancybox" rel="gallery1" href="images/gallery/gallery2.jpg" title="Gallery Tittle One">
                                    <img src="images/gallery/gallery-small-thumb2.jpg" alt="" />
                                </a>
                            </div>
                            <div class="thumb-small-gallery">
                                <a class="fancybox" rel="gallery1" href="images/gallery/gallery3.jpg" title="Gallery Tittle One">
                                    <img src="images/gallery/gallery-small-thumb3.jpg" alt="" />
                                </a>
                            </div>
                            <div class="thumb-small-gallery">
                                <a class="fancybox" rel="gallery1" href="images/gallery/gallery4.jpg" title="Gallery Tittle One">
                                    <img src="images/gallery/gallery-small-thumb4.jpg" alt="" />
                                </a>
                            </div>
                            <div class="thumb-small-gallery">
                                <a class="fancybox" rel="gallery1" href="images/gallery/gallery5.jpg" title="Gallery Tittle One">
                                    <img src="images/gallery/gallery-small-thumb5.jpg" alt="" />
                                </a>
                            </div>
                            <div class="thumb-small-gallery">
                                <a class="fancybox" rel="gallery1" href="images/gallery/gallery6.jpg" title="Gallery Tittle One">
                                    <img src="images/gallery/gallery-small-thumb6.jpg" alt="" />
                                </a>
                            </div>
                            <div class="thumb-small-gallery">
                                <a class="fancybox" rel="gallery1" href="images/gallery/gallery7.jpg" title="Gallery Tittle One">
                                    <img src="images/gallery/gallery-small-thumb7.jpg" alt="" />
                                </a>
                            </div>
                            <div class="thumb-small-gallery">
                                <a class="fancybox" rel="gallery1" href="images/gallery/gallery8.jpg" title="Gallery Tittle One">
                                    <img src="images/gallery/gallery-small-thumb8.jpg" alt="" />
                                </a>
                            </div>
                        </div> <!-- /.galler-small-thumbs -->
                    </div> <!-- /.widget-inner -->
                </div> <!-- /.widget-main -->

            </div> <!-- /.col-md-4 -->
    
        </div> <!-- /.row -->
    </div> <!-- /.container -->

    <!-- begin The Footer -->
    <footer class="site-footer">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <div class="footer-widget">
                        <h4 class="footer-widget-title">Contact Us</h4>
                        <p>The simple contact form below comes packed within this theme. </br></br>Mailing address:</br>877 Filbert Street</br> Chester, PA 19013</p>
                    </div>
                </div>
                <div class="col-md-2 col-sm-4">
                    <div class="footer-widget">
                        <h4 class="footer-widget-title">Favourites</h4>
                        <ul class="list-links">
                            <li><a href="#">A to Z Index</a></li>
                            <li><a href="#">Admissions</a></li>
                            <li><a href="#">Bookstore</a></li>
                            <li><a href="#">Catalog / Classes</a></li>
                            <li><a href="#">Dining</a></li>
                            <li><a href="#">Financial Aid</a></li>
                            <li><a href="#">Graduation</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-2 col-sm-4">
                    <div class="footer-widget">
                        <h4 class="footer-widget-title">Resources For</h4>
                        <ul class="list-links">
                            <li><a href="#">Future Students</a></li>
                            <li><a href="#">Current Students</a></li>
                            <li><a href="#">Faculty/Staff</a></li>
                            <li><a href="#">International</a></li>
                            <li><a href="#">Postdocs</a></li>
                            <li><a href="#">Alumni</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-2 col-sm-4">
                    <div class="footer-widget">
                        <h4 class="footer-widget-title">Study</h4>
                        <ul class="list-links">
                            <li><a href="#">Courses</a></li>
                            <li><a href="#">Apply Now</a></li>
                            <li><a href="#">Scholarships</a></li>
                            <li><a href="#">FAQs</a></li>
                            <li><a href="#">International student enquiries</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="footer-widget">
                        <ul class="footer-media-icons">
                            <li><a href="#" class="fa fa-facebook"></a></li>
                            <li><a href="#" class="fa fa-twitter"></a></li>
                            <li><a href="#" class="fa fa-google-plus"></a></li>
                            <li><a href="#" class="fa fa-youtube"></a></li>
                            <li><a href="#" class="fa fa-linkedin"></a></li>
                            <li><a href="#" class="fa fa-instagram"></a></li>
                            <li><a href="#" class="fa fa-apple"></a></li>
                            <li><a href="#" class="fa fa-rss"></a></li>
                        </ul>
                    </div>
                </div>
            </div> <!-- /.row -->

            <div class="bottom-footer">
                <div class="row">
                    <div class="col-md-5">
                        <p class="small-text">&copy; Copyright 2014. Universe designed by <a href="#">Jetsitem</a></p>
                    </div> <!-- /.col-md-5 -->
                    <div class="col-md-7">
                        <ul class="footer-nav">
                            <li><a href="index.php">Home</a></li>
                            <li><a href="courses.php">Courses</a></li>
                            <li><a href="events-list.php">Events</a></li>
                            <li><a href="blog.php">Blog</a></li>
                            <li><a href="shortcodes.php">Shortcodes</a></li>
                            <li><a href="contact.php">Contact</a></li>
                        </ul>
                    </div> <!-- /.col-md-7 -->
                </div> <!-- /.row -->
            </div> <!-- /.bottom-footer -->

        </div> <!-- /.container -->
    </footer> <!-- /.site-footer -->


    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="js/plugins.js"></script>
    <script src="js/custom.js"></script>

</body>

<!-- Mirrored from demo.esmeth.com/universe/Blue/courses.php by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 12 Feb 2015 19:12:26 GMT -->

<!-- Mirrored from www.jetsitem.net/template/template075/courses.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 22 May 2016 14:25:39 GMT -->
</html>